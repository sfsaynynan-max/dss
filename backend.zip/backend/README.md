# Learn Arabic Platform - Backend

## Setup على Railway

### 1. متغيرات البيئة (Environment Variables)
في Railway dashboard أضف هذه المتغيرات:

```
DATABASE_URL=postgresql://...  ← من Railway PostgreSQL plugin
SECRET_KEY=أي-نص-عشوائي-طويل
DEEPSEEK_API_KEY=sk-...
ADMIN_USERNAME=admin
ADMIN_PASSWORD=كلمة-مرور-قوية
WHISPER_MODEL=base
```

### 2. إضافة PostgreSQL
- في Railway: New → Database → PostgreSQL
- انسخ الـ DATABASE_URL وضعه في المتغيرات

### 3. Deploy
```bash
# رفع الكود على GitHub ثم ربطه بـ Railway
git init
git add .
git commit -m "initial"
git push
```

## API Endpoints

### Admin (يحتاج token)
| Method | Endpoint | الوصف |
|--------|----------|-------|
| POST | /api/admin/login | تسجيل دخول |
| GET | /api/admin/categories | عرض المجالات |
| POST | /api/admin/categories | إضافة مجال |
| DELETE | /api/admin/categories/{id} | حذف مجال |
| GET | /api/admin/courses | عرض الدورات |
| POST | /api/admin/courses | إضافة دورة |
| DELETE | /api/admin/courses/{id} | حذف دورة |
| GET | /api/admin/courses/{id}/status | حالة المعالجة |

### Public (تطبيق Flutter)
| Method | Endpoint | الوصف |
|--------|----------|-------|
| GET | /api/categories | المجالات |
| GET | /api/courses?category_id=1 | الدورات |
| GET | /api/courses/{id} | تفاصيل دورة كاملة |
| POST | /api/lectures/{id}/rate | تقييم محاضرة |
| POST | /api/lectures/{id}/progress | حفظ التقدم |
| GET | /api/progress/{device_id} | جلب تقدم المستخدم |

## نموذج إضافة دورة

```json
POST /api/admin/courses
{
  "title": "Introduction to AI",
  "description": "Complete AI course for beginners",
  "category_id": 1,
  "lectures": [
    {"youtube_url": "https://youtube.com/watch?v=xxx", "title": "Lecture 1"},
    {"youtube_url": "https://youtube.com/watch?v=yyy", "title": "Lecture 2"}
  ]
}
```

بعد الإرسال، كل محاضرة تمر بـ Pipeline:
1. ⬇️ تحميل الصوت (yt-dlp)
2. 🎙️ تفريغ النص (Whisper)
3. 🌐 ترجمة عربية (DeepSeek)
4. 📑 تقسيم ذكي لفقرات (DeepSeek)
