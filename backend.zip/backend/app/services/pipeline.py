import os
import re
import json
import tempfile
import asyncio
import httpx
import yt_dlp
import whisper
from typing import List, Dict
from app.core.config import settings

# Load Whisper model once at startup
_whisper_model = None

def get_whisper_model():
    global _whisper_model
    if _whisper_model is None:
        print(f"Loading Whisper model: {settings.WHISPER_MODEL}")
        _whisper_model = whisper.load_model(settings.WHISPER_MODEL)
    return _whisper_model

def extract_youtube_id(url: str) -> str:
    patterns = [
        r"(?:v=|youtu\.be/|embed/)([a-zA-Z0-9_-]{11})",
    ]
    for p in patterns:
        m = re.search(p, url)
        if m:
            return m.group(1)
    return ""

def download_audio(youtube_url: str, output_dir: str) -> str:
    """Download audio from YouTube, return path to audio file."""
    ydl_opts = {
        "format": "bestaudio/best",
        "outtmpl": os.path.join(output_dir, "audio.%(ext)s"),
        "postprocessors": [{
            "key": "FFmpegExtractAudio",
            "preferredcodec": "mp3",
            "preferredquality": "128",
        }],
        "quiet": True,
        "no_warnings": True,
    }
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(youtube_url, download=True)
        duration = info.get("duration", 0)
    return os.path.join(output_dir, "audio.mp3"), duration

def transcribe_audio(audio_path: str) -> List[Dict]:
    """Transcribe audio using Whisper, return segments with timing."""
    model = get_whisper_model()
    result = model.transcribe(audio_path, task="transcribe", verbose=False)
    segments = []
    for seg in result["segments"]:
        segments.append({
            "start": seg["start"],
            "end": seg["end"],
            "text": seg["text"].strip()
        })
    return segments

async def translate_subtitles(segments: List[Dict]) -> List[Dict]:
    """Translate subtitle segments to Arabic using DeepSeek."""
    # Batch segments for efficiency (50 at a time)
    batch_size = 50
    translated = []

    for i in range(0, len(segments), batch_size):
        batch = segments[i:i+batch_size]
        texts = [s["text"] for s in batch]
        numbered = "\n".join([f"{j+1}. {t}" for j, t in enumerate(texts)])

        prompt = f"""ترجم النصوص التالية من الإنجليزية إلى العربية الفصحى المبسطة.
أعد الترجمة بنفس الترقيم فقط، لا تضف أي كلام آخر.

{numbered}"""

        response = await call_deepseek(prompt)
        lines = response.strip().split("\n")

        for j, seg in enumerate(batch):
            ar_text = ""
            if j < len(lines):
                line = lines[j].strip()
                # Remove numbering like "1. " or "١. "
                line = re.sub(r"^\d+\.\s*", "", line)
                ar_text = line
            translated.append({
                "start": seg["start"],
                "end": seg["end"],
                "text_en": seg["text"],
                "text_ar": ar_text
            })

    return translated

async def generate_segments(subtitles: List[Dict], lecture_title: str) -> List[Dict]:
    """Use DeepSeek to intelligently segment the lecture into chapters."""
    # Build full transcript
    full_text = " ".join([f"[{s['start']:.0f}s] {s['text_en']}" for s in subtitles[:200]])

    prompt = f"""المحاضرة: "{lecture_title}"

النص التالي هو محاضرة تعليمية مع timestamps بالثواني:
{full_text[:6000]}

قسّم هذه المحاضرة إلى فقرات/فصول منطقية (من 3 إلى 8 فقرات).
لكل فقرة أعطني:
- عنوان عربي مختصر وواضح
- وقت البداية بالثواني

أعد JSON فقط بهذا الشكل (لا تضف أي نص آخر):
[
  {{"title_ar": "مقدمة وأهداف المحاضرة", "start_time": 0}},
  {{"title_ar": "المفاهيم الأساسية", "start_time": 180}}
]"""

    response = await call_deepseek(prompt)

    try:
        # Extract JSON from response
        json_match = re.search(r"\[.*\]", response, re.DOTALL)
        if json_match:
            raw_segments = json.loads(json_match.group())
            result = []
            for idx, seg in enumerate(raw_segments):
                start = float(seg.get("start_time", 0))
                # Calculate end_time from next segment or total duration
                if idx + 1 < len(raw_segments):
                    end = float(raw_segments[idx+1].get("start_time", start + 60))
                else:
                    end = subtitles[-1]["end"] if subtitles else start + 60
                result.append({
                    "title_ar": seg.get("title_ar", f"الجزء {idx+1}"),
                    "start_time": start,
                    "end_time": end,
                    "order": idx
                })
            return result
    except Exception as e:
        print(f"Segment parsing error: {e}")

    # Fallback: split into equal parts
    if subtitles:
        total = subtitles[-1]["end"]
        part = total / 4
        return [
            {"title_ar": "المقدمة", "start_time": 0, "end_time": part, "order": 0},
            {"title_ar": "الجزء الأول", "start_time": part, "end_time": part*2, "order": 1},
            {"title_ar": "الجزء الثاني", "start_time": part*2, "end_time": part*3, "order": 2},
            {"title_ar": "الخلاصة", "start_time": part*3, "end_time": total, "order": 3},
        ]
    return []

async def translate_course_metadata(title: str, description: str) -> Dict:
    """Translate course title and description to Arabic."""
    prompt = f"""ترجم النص التالي إلى العربية الفصحى المبسطة.
أعد JSON فقط بهذا الشكل:
{{"title_ar": "...", "description_ar": "..."}}

العنوان: {title}
الوصف: {description or ""}"""

    response = await call_deepseek(prompt)
    try:
        json_match = re.search(r"\{.*\}", response, re.DOTALL)
        if json_match:
            return json.loads(json_match.group())
    except:
        pass
    return {"title_ar": title, "description_ar": description}

async def call_deepseek(prompt: str) -> str:
    """Call DeepSeek API."""
    async with httpx.AsyncClient(timeout=120) as client:
        response = await client.post(
            "https://api.deepseek.com/chat/completions",
            headers={
                "Authorization": f"Bearer {settings.DEEPSEEK_API_KEY}",
                "Content-Type": "application/json"
            },
            json={
                "model": "deepseek-chat",
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": 4000,
                "temperature": 0.3
            }
        )
        response.raise_for_status()
        return response.json()["choices"][0]["message"]["content"]

async def process_lecture(lecture_id: int, youtube_url: str, title: str, db_session_factory):
    """Full processing pipeline for one lecture."""
    from app.models.models import Lecture, Subtitle, Segment
    
    db = db_session_factory()
    try:
        # Update status to processing
        lecture = db.query(Lecture).filter(Lecture.id == lecture_id).first()
        lecture.status = "processing"
        db.commit()

        with tempfile.TemporaryDirectory() as tmpdir:
            # 1. Download audio
            print(f"[{lecture_id}] Downloading audio...")
            audio_path, duration = download_audio(youtube_url, tmpdir)
            lecture.duration_seconds = int(duration)
            db.commit()

            # 2. Transcribe
            print(f"[{lecture_id}] Transcribing...")
            raw_segments = transcribe_audio(audio_path)

            # 3. Translate subtitles
            print(f"[{lecture_id}] Translating subtitles...")
            translated = await translate_subtitles(raw_segments)

            # 4. Save subtitles
            for sub in translated:
                db.add(Subtitle(
                    lecture_id=lecture_id,
                    start_time=sub["start"],
                    end_time=sub["end"],
                    text_en=sub["text_en"],
                    text_ar=sub["text_ar"]
                ))

            # 5. Generate smart segments
            print(f"[{lecture_id}] Generating segments...")
            segments = await generate_segments(translated, title)
            for seg in segments:
                db.add(Segment(
                    lecture_id=lecture_id,
                    title_ar=seg["title_ar"],
                    start_time=seg["start_time"],
                    end_time=seg["end_time"],
                    order=seg["order"]
                ))

            # 6. Mark done
            lecture.status = "done"
            db.commit()
            print(f"[{lecture_id}] Done ✓")

    except Exception as e:
        print(f"[{lecture_id}] Error: {e}")
        lecture = db.query(Lecture).filter(Lecture.id == lecture_id).first()
        lecture.status = "failed"
        lecture.error_message = str(e)
        db.commit()
    finally:
        db.close()
