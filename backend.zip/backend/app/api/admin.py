import asyncio
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.core.auth import verify_admin, verify_password, hash_password, create_access_token
from app.core.config import settings
from app.models.models import Category, Course, Lecture
from app.schemas.schemas import (
    LoginRequest, TokenResponse, CategoryCreate, CategoryOut,
    CourseCreate, CourseOut, CourseListItem
)
from app.services.pipeline import (
    extract_youtube_id, process_lecture, translate_course_metadata
)
from typing import List

router = APIRouter(prefix="/api/admin", tags=["admin"])

# ─── Auth ────────────────────────────────────────────────
@router.post("/login", response_model=TokenResponse)
def login(req: LoginRequest):
    if req.username != settings.ADMIN_USERNAME or req.password != settings.ADMIN_PASSWORD:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = create_access_token({"sub": req.username, "role": "admin"})
    return {"access_token": token}

# ─── Categories ──────────────────────────────────────────
@router.get("/categories", response_model=List[CategoryOut])
def get_categories(db: Session = Depends(get_db), _=Depends(verify_admin)):
    return db.query(Category).all()

@router.post("/categories", response_model=CategoryOut)
def create_category(data: CategoryCreate, db: Session = Depends(get_db), _=Depends(verify_admin)):
    cat = Category(**data.model_dump())
    db.add(cat)
    db.commit()
    db.refresh(cat)
    return cat

@router.delete("/categories/{cat_id}")
def delete_category(cat_id: int, db: Session = Depends(get_db), _=Depends(verify_admin)):
    cat = db.query(Category).filter(Category.id == cat_id).first()
    if not cat:
        raise HTTPException(status_code=404)
    cat.is_active = False
    db.commit()
    return {"ok": True}

# ─── Courses ─────────────────────────────────────────────
@router.get("/courses", response_model=List[CourseListItem])
def list_courses(db: Session = Depends(get_db), _=Depends(verify_admin)):
    courses = db.query(Course).all()
    result = []
    for c in courses:
        item = CourseListItem(
            id=c.id,
            title=c.title,
            title_ar=c.title_ar,
            description_ar=c.description_ar,
            thumbnail_url=c.thumbnail_url,
            category_id=c.category_id,
            lectures_count=len(c.lectures)
        )
        result.append(item)
    return result

@router.post("/courses")
async def create_course(
    data: CourseCreate,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    _=Depends(verify_admin)
):
    # Translate metadata
    meta = await translate_course_metadata(data.title, data.description or "")

    # Create course
    course = Course(
        title=data.title,
        title_ar=meta.get("title_ar"),
        description=data.description,
        description_ar=meta.get("description_ar"),
        category_id=data.category_id,
        published_at=data.published_at,
        is_published=True
    )
    db.add(course)
    db.commit()
    db.refresh(course)

    # Create lectures and queue processing
    from app.core.database import SessionLocal

    for idx, lec_input in enumerate(data.lectures):
        yt_id = extract_youtube_id(lec_input.youtube_url)
        lecture = Lecture(
            course_id=course.id,
            title=lec_input.title,
            youtube_url=lec_input.youtube_url,
            youtube_id=yt_id,
            order=idx,
            status="pending",
            thumbnail_url=f"https://img.youtube.com/vi/{yt_id}/hqdefault.jpg" if yt_id else None
        )
        db.add(lecture)
        db.commit()
        db.refresh(lecture)

        # Queue background processing
        background_tasks.add_task(
            process_lecture,
            lecture.id,
            lec_input.youtube_url,
            lec_input.title,
            SessionLocal
        )

    return {"course_id": course.id, "lectures_queued": len(data.lectures)}

@router.delete("/courses/{course_id}")
def delete_course(course_id: int, db: Session = Depends(get_db), _=Depends(verify_admin)):
    course = db.query(Course).filter(Course.id == course_id).first()
    if not course:
        raise HTTPException(status_code=404)
    course.is_published = False
    db.commit()
    return {"ok": True}

@router.get("/courses/{course_id}/status")
def course_status(course_id: int, db: Session = Depends(get_db), _=Depends(verify_admin)):
    lectures = db.query(Lecture).filter(Lecture.course_id == course_id).all()
    return [{
        "id": l.id,
        "title": l.title,
        "status": l.status,
        "error": l.error_message
    } for l in lectures]
