from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.core.database import get_db
from app.models.models import Category, Course, Lecture, Rating, UserProgress, Subtitle, Segment
from app.schemas.schemas import (
    CourseOut, CourseListItem, CategoryOut,
    RatingCreate, ProgressUpdate, LectureOut, SubtitleOut, SegmentOut
)
from typing import List

router = APIRouter(prefix="/api", tags=["app"])

# ─── Categories ──────────────────────────────────────────
@router.get("/categories", response_model=List[CategoryOut])
def get_categories(db: Session = Depends(get_db)):
    return db.query(Category).filter(Category.is_active == True).all()

# ─── Courses ─────────────────────────────────────────────
@router.get("/courses", response_model=List[CourseListItem])
def list_courses(category_id: int = None, db: Session = Depends(get_db)):
    q = db.query(Course).filter(Course.is_published == True)
    if category_id:
        q = q.filter(Course.category_id == category_id)
    courses = q.all()
    result = []
    for c in courses:
        result.append(CourseListItem(
            id=c.id,
            title=c.title,
            title_ar=c.title_ar,
            description_ar=c.description_ar,
            thumbnail_url=c.thumbnail_url,
            category_id=c.category_id,
            lectures_count=len(c.lectures)
        ))
    return result

@router.get("/courses/{course_id}", response_model=CourseOut)
def get_course(course_id: int, db: Session = Depends(get_db)):
    course = db.query(Course).filter(Course.id == course_id, Course.is_published == True).first()
    if not course:
        raise HTTPException(status_code=404)

    lectures_out = []
    for lec in course.lectures:
        likes = db.query(func.count(Rating.id)).filter(
            Rating.lecture_id == lec.id,
            Rating.is_positive == True
        ).scalar()

        lectures_out.append(LectureOut(
            id=lec.id,
            title=lec.title,
            title_ar=lec.title_ar,
            youtube_id=lec.youtube_id,
            order=lec.order,
            duration_seconds=lec.duration_seconds,
            status=lec.status,
            subtitles=[SubtitleOut(
                start_time=s.start_time,
                end_time=s.end_time,
                text_ar=s.text_ar
            ) for s in sorted(lec.subtitles, key=lambda x: x.start_time)],
            segments=[SegmentOut(
                title_ar=s.title_ar,
                start_time=s.start_time,
                end_time=s.end_time,
                order=s.order
            ) for s in sorted(lec.segments, key=lambda x: x.order)],
            likes_count=likes
        ))

    return CourseOut(
        id=course.id,
        title=course.title,
        title_ar=course.title_ar,
        description=course.description,
        description_ar=course.description_ar,
        thumbnail_url=course.thumbnail_url,
        category_id=course.category_id,
        is_published=course.is_published,
        published_at=course.published_at,
        lectures=lectures_out
    )

# ─── Rating ──────────────────────────────────────────────
@router.post("/lectures/{lecture_id}/rate")
def rate_lecture(lecture_id: int, data: RatingCreate, db: Session = Depends(get_db)):
    # Check if already rated by this device
    existing = db.query(Rating).filter(
        Rating.lecture_id == lecture_id,
        Rating.device_id == data.device_id
    ).first()

    if existing:
        existing.is_positive = data.is_positive
        existing.feedback = data.feedback
    else:
        db.add(Rating(
            lecture_id=lecture_id,
            device_id=data.device_id,
            is_positive=data.is_positive,
            feedback=data.feedback
        ))
    db.commit()
    return {"ok": True}

# ─── Progress ────────────────────────────────────────────
@router.post("/lectures/{lecture_id}/progress")
def update_progress(lecture_id: int, data: ProgressUpdate, db: Session = Depends(get_db)):
    progress = db.query(UserProgress).filter(
        UserProgress.lecture_id == lecture_id,
        UserProgress.device_id == data.device_id
    ).first()

    if progress:
        progress.last_position = data.last_position
        progress.is_completed = data.is_completed
    else:
        db.add(UserProgress(
            lecture_id=lecture_id,
            device_id=data.device_id,
            last_position=data.last_position,
            is_completed=data.is_completed
        ))
    db.commit()
    return {"ok": True}

@router.get("/progress/{device_id}")
def get_progress(device_id: str, db: Session = Depends(get_db)):
    progress = db.query(UserProgress).filter(UserProgress.device_id == device_id).all()
    return [{
        "lecture_id": p.lecture_id,
        "last_position": p.last_position,
        "is_completed": p.is_completed
    } for p in progress]
