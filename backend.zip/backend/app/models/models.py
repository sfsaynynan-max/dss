from sqlalchemy import Column, Integer, String, Text, DateTime, Float, Boolean, ForeignKey, JSON
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.core.database import Base

class Category(Base):
    __tablename__ = "categories"
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    name_ar = Column(String(100), nullable=False)
    icon = Column(String(50))
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    courses = relationship("Course", back_populates="category")

class Course(Base):
    __tablename__ = "courses"
    id = Column(Integer, primary_key=True)
    title = Column(String(200), nullable=False)
    title_ar = Column(String(200))
    description = Column(Text)
    description_ar = Column(Text)
    thumbnail_url = Column(String(500))
    category_id = Column(Integer, ForeignKey("categories.id"))
    published_at = Column(DateTime(timezone=True))
    is_published = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    category = relationship("Category", back_populates="courses")
    lectures = relationship("Lecture", back_populates="course", order_by="Lecture.order")

class Lecture(Base):
    __tablename__ = "lectures"
    id = Column(Integer, primary_key=True)
    course_id = Column(Integer, ForeignKey("courses.id"))
    title = Column(String(200), nullable=False)
    title_ar = Column(String(200))
    youtube_url = Column(String(500), nullable=False)
    youtube_id = Column(String(50))
    order = Column(Integer, default=0)
    duration_seconds = Column(Integer)
    status = Column(String(30), default="pending")
    # pending | processing | done | failed
    error_message = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    course = relationship("Course", back_populates="lectures")
    subtitles = relationship("Subtitle", back_populates="lecture")
    segments = relationship("Segment", back_populates="lecture")
    ratings = relationship("Rating", back_populates="lecture")
    progresses = relationship("UserProgress", back_populates="lecture")

class Subtitle(Base):
    __tablename__ = "subtitles"
    id = Column(Integer, primary_key=True)
    lecture_id = Column(Integer, ForeignKey("lectures.id"))
    start_time = Column(Float, nullable=False)  # seconds
    end_time = Column(Float, nullable=False)
    text_en = Column(Text)
    text_ar = Column(Text)
    lecture = relationship("Lecture", back_populates="subtitles")

class Segment(Base):
    __tablename__ = "segments"
    id = Column(Integer, primary_key=True)
    lecture_id = Column(Integer, ForeignKey("lectures.id"))
    title_ar = Column(String(300))
    start_time = Column(Float)  # seconds
    end_time = Column(Float)
    order = Column(Integer)
    lecture = relationship("Lecture", back_populates="segments")

class Rating(Base):
    __tablename__ = "ratings"
    id = Column(Integer, primary_key=True)
    lecture_id = Column(Integer, ForeignKey("lectures.id"))
    device_id = Column(String(100))  # anonymous device id
    is_positive = Column(Boolean)
    feedback = Column(Text)  # negative feedback text
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    lecture = relationship("Lecture", back_populates="ratings")

class UserProgress(Base):
    __tablename__ = "user_progress"
    id = Column(Integer, primary_key=True)
    lecture_id = Column(Integer, ForeignKey("lectures.id"))
    device_id = Column(String(100))
    last_position = Column(Float, default=0)  # seconds
    is_completed = Column(Boolean, default=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    lecture = relationship("Lecture", back_populates="progresses")
