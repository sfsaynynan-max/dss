from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime

# ─── Auth ───────────────────────────────────────────────
class LoginRequest(BaseModel):
    username: str
    password: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"

# ─── Category ───────────────────────────────────────────
class CategoryCreate(BaseModel):
    name: str
    name_ar: str
    icon: Optional[str] = None

class CategoryOut(BaseModel):
    id: int
    name: str
    name_ar: str
    icon: Optional[str]
    is_active: bool
    class Config: from_attributes = True

# ─── Course ─────────────────────────────────────────────
class LectureInput(BaseModel):
    youtube_url: str
    title: str

class CourseCreate(BaseModel):
    title: str
    description: Optional[str] = None
    category_id: int
    published_at: Optional[datetime] = None
    lectures: List[LectureInput]

class SubtitleOut(BaseModel):
    start_time: float
    end_time: float
    text_ar: str
    class Config: from_attributes = True

class SegmentOut(BaseModel):
    title_ar: str
    start_time: float
    end_time: float
    order: int
    class Config: from_attributes = True

class LectureOut(BaseModel):
    id: int
    title: str
    title_ar: Optional[str]
    youtube_id: Optional[str]
    order: int
    duration_seconds: Optional[int]
    status: str
    subtitles: List[SubtitleOut] = []
    segments: List[SegmentOut] = []
    likes_count: int = 0
    class Config: from_attributes = True

class CourseOut(BaseModel):
    id: int
    title: str
    title_ar: Optional[str]
    description: Optional[str]
    description_ar: Optional[str]
    thumbnail_url: Optional[str]
    category_id: int
    is_published: bool
    published_at: Optional[datetime]
    lectures: List[LectureOut] = []
    class Config: from_attributes = True

class CourseListItem(BaseModel):
    id: int
    title: str
    title_ar: Optional[str]
    description_ar: Optional[str]
    thumbnail_url: Optional[str]
    category_id: int
    lectures_count: int = 0
    class Config: from_attributes = True

# ─── Rating ─────────────────────────────────────────────
class RatingCreate(BaseModel):
    device_id: str
    is_positive: bool
    feedback: Optional[str] = None

# ─── Progress ───────────────────────────────────────────
class ProgressUpdate(BaseModel):
    device_id: str
    last_position: float
    is_completed: bool = False
