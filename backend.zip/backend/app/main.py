from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.core.database import engine, Base
from app.api import admin, public
from app.models import models  # ensure models are registered

# Create all tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Learn Arabic API",
    description="Backend for Arabic educational platform",
    version="1.0.0"
)

# CORS - allow Flutter app and admin panel
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(admin.router)
app.include_router(public.router)

@app.get("/health")
def health():
    return {"status": "ok"}

@app.on_event("startup")
async def startup():
    """Seed default categories on first run."""
    from app.core.database import SessionLocal
    from app.models.models import Category
    db = SessionLocal()
    try:
        count = db.query(Category).count()
        if count == 0:
            defaults = [
                Category(name="Artificial Intelligence", name_ar="الذكاء الاصطناعي", icon="🤖"),
                Category(name="Business Management", name_ar="إدارة الأعمال", icon="💼"),
                Category(name="Cybersecurity", name_ar="الأمن السيبراني", icon="🔐"),
            ]
            db.add_all(defaults)
            db.commit()
            print("Default categories seeded ✓")
    finally:
        db.close()
